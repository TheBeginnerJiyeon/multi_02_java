package com.multi.homework.a_interface.dto;

public interface KoreanInterface {

	String LOCATION="EAST-ASIA";
	String COUNTRY="KOREA";
	
	public void spicy();
	public void sleep();
	public void work();




}
