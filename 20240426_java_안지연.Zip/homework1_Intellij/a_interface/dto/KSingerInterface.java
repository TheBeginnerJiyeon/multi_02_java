package com.multi.homework.a_interface.dto;

public interface KSingerInterface extends KoreanInterface{
	
	public void sing();
	public void dance();
	public void act();
	
	
	
	
	
	
}
