package org.example.b_poii_jar.run;


import org.example.b_poii_jar.view.View;

public class Main {
	public static void main(String[] args) {
		
		View view = new View();
		view.viewNews();
		
		
	}
}
