package com.multi.homework;

public class MyCafe4 {
	
	int sum(int count, int price) {
		int result=count*price;
	
		return result;
	}
	
	int div(int sum, int person){
		int result=sum/person;
		
		return result;
	}
	
	int total(int sum, int sum2){
		int result=sum+sum2;
		return result;
	}
	
	
	
	
	
	
}
