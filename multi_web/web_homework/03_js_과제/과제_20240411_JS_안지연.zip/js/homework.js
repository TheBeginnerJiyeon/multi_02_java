function travel(place){
    document.write("TRAVEL TO " + place)
    document.write("<br>")
}

function rest(time) {
    document.write("rest for " + time + " hour")
}