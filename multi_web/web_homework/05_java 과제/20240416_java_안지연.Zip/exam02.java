package com.multi.homework;

public class exam02 {
	public static void main(String[] args) {
		String heigth= "199.9";
		double heigth1=Double.parseDouble(heigth);
		double weight=(double) (heigth1-100)*0.9;
		System.out.println(weight);
		
	}
}
