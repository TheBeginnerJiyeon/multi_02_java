package com.multi.homework;

public class MainThread {
	
	public static void main(String[] args) {
		
		
		View v1 = new View();
		v1.view();
		
		
		
	}
	
	
}
